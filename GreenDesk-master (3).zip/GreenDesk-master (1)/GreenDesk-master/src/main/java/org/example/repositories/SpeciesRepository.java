package org.example.repositories;

import org.example.entites.Species;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository amélioré pour l'entité Species
 * Inspiré des bonnes pratiques du projet GreenDesk, adapté à MongoDB
 */
@Repository
public interface SpeciesRepository extends MongoRepository<Species, String> {

    // --- RECHERCHES PAR NOM ---

    /**
     * Trouver une espèce par son nom exact (Sensible à la casse)
     */
    Optional<Species> findByName(String name);

    /**
     * ✅ AJOUTÉ : Trouver une espèce par nom en ignorant la casse (ex: "tomato" trouve "Tomato")
     * Utile pour éviter les doublons lors de la création.
     */
    Optional<Species> findByNameIgnoreCase(String name);

    /**
     * ✅ AJOUTÉ : Recherche partielle pour la barre de recherche (ex: "Tom" trouve "Tomato", "Tomate", etc.)
     */
    List<Species> findByNameContainingIgnoreCase(String name);

    /**
     * ✅ AJOUTÉ : Vérifie simplement si une espèce existe (plus rapide que de récupérer l'objet)
     * Utile pour les validateurs avant création.
     */
    boolean existsByNameIgnoreCase(String name);


    // --- FILTRES ENVIRONNEMENTAUX ---

    /**
     * Trouver les espèces par plage de besoins en eau
     */
    List<Species> findByOptimalWaterNeedsBetween(double min, double max);

    /**
     * Trouver les espèces adaptées à une plage de température
     */
    List<Species> findByOptimalTemperatureBetween(double min, double max);

    /**
     * Trouver les espèces adaptées à une plage d'humidité
     */
    List<Species> findByOptimalHumidityBetween(double min, double max);

    /**
     * Trouver les espèces adaptées à une plage de lumière (lux)
     */
    List<Species> findByOptimalLuxNeedsBetween(double min, double max);

    /**
     * Trouver les espèces qui tolèrent une température maximale donnée
     */
    List<Species> findByOptimalTemperatureLessThanEqual(double maxTemp);

    /**
     * Trouver les espèces qui supportent beaucoup de lumière
     */
    List<Species> findByOptimalLuxNeedsGreaterThanEqual(double minLux);

    /**
     * Trouver les espèces à croissance rapide
     */
    List<Species> findByBaseGrowthRateGreaterThanEqual(double minGrowthRate);


    // --- TRIS ---

    /**
     * Toutes les espèces triées par besoin en eau croissant
     */
    List<Species> findAllByOrderByOptimalWaterNeedsAsc();

    /**
     * Toutes les espèces triées par taux de croissance décroissant
     */
    List<Species> findAllByOrderByBaseGrowthRateDesc();
}