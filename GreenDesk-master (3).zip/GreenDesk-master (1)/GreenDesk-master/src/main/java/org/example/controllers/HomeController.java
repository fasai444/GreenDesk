package org.example.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    // Redirige la racine "/" vers notre fichier index.html
    @GetMapping("/")
    public String home() {
        return "forward:/index.html";
    }

    // Garde l'accès à Swagger via l'URL /swagger
    @GetMapping("/swagger")
    public String swagger() {
        return "redirect:/swagger-ui.html";
    }
}