package org.example.repositories;

import org.example.entites.Forest;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository amélioré pour l'entité Forest
 * Permet la gestion des environnements de simulation
 */
@Repository
public interface ForestRepository extends MongoRepository<Forest, String> {

    // --- RECHERCHE PAR NOM ---

    /**
     * Trouver une forêt par son nom exact
     */
    Optional<Forest> findByName(String name);

    /**
     * ✅ AJOUTÉ : Trouver une forêt en ignorant la casse (ex: "amazonie" trouve "Amazonie")
     * Utile pour la validation et l'UX.
     */
    Optional<Forest> findByNameIgnoreCase(String name);

    /**
     * ✅ AJOUTÉ : Recherche partielle pour la barre de recherche (ex: "Ama" trouve "Amazonie")
     * Indispensable pour l'auto-complétion dans le Frontend.
     */
    List<Forest> findByNameContainingIgnoreCase(String name);

    /**
     * ✅ AJOUTÉ : Vérifie si une forêt existe déjà avec ce nom (Validation rapide)
     * À utiliser dans le Service avant de créer une nouvelle forêt.
     */
    boolean existsByNameIgnoreCase(String name);


    // --- FILTRES PAR DIMENSIONS ---

    /**
     * Trouver les forêts qui ont au moins une certaine surface
     * (Note: Spring Data ne peut pas calculer width*height tout seul ici, 
     * donc on filtre souvent par largeur ou hauteur minimale).
     */
    List<Forest> findByWidthGreaterThanEqualAndHeightGreaterThanEqual(int minWidth, int minHeight);

    /**
     * Trouver les "petites" forêts (ex: largeur inférieure à 10)
     */
    List<Forest> findByWidthLessThan(int maxWidth);


    // --- TRIS ---

    /**
     * Obtenir toutes les forêts triées par ordre alphabétique
     * (Très utile pour remplir proprement la liste déroulante <select> du Frontend)
     */
    List<Forest> findAllByOrderByNameAsc();
}